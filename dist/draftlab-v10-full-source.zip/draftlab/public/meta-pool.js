(function(root){
'use strict';
function normalize(metas,ids){const allowed=new Set(metas.filter(m=>!m.composite).map(m=>m.id));return [...new Set(ids||[])].filter(id=>allowed.has(id)).sort();}
function combine(metas,ids){
 const chosen=normalize(metas,ids);if(!chosen.length)throw new Error('Выберите хотя бы одну турнирную мету');
 const sources=chosen.map(id=>metas.find(m=>m.id===id));if(sources.length===1)return {...sources[0],metaIds:chosen,sources,composite:false};
 const allIds=normalize(metas,metas.map(m=>m.id)),isAll=chosen.length===allIds.length;const keys=new Set(sources.flatMap(m=>Object.keys(m.stats)));const stats={};
 for(const slug of keys){let picks=0,bans=0,wins=0,games=0;const observed=[],roles={};for(const m of sources){const s=m.stats[slug];if(m.partial&&!s)continue;games+=m.games;observed.push(m.id);if(s){picks+=s.picks;bans+=s.bans;wins+=Number.isFinite(s.wins)?s.wins:s.picks*(s.wr||0)/100;for(const [role,row] of Object.entries(s.roles||{})){const r=roles[role]||(roles[role]={picks:0,wins:0});r.picks+=row.picks;r.wins+=row.wins;}}}
  for(const r of Object.values(roles))r.wr=r.wins/r.picks*100;
  if(picks+bans)stats[slug]={picks,wins,bans,wr:picks?wins/picks*100:null,presence:games?(picks+bans)/games*100:0,sampleGames:games,sources:observed,roles};
 }
 const firstWindow=sources[0].window,window=firstWindow&&sources.every(m=>JSON.stringify(m.window)===JSON.stringify(firstWindow))?firstWindow:null;
 const coverage=sources.every(m=>m.coverage)?{kind:'available-records',completeTournament:false,...Object.fromEntries(['candidates','accepted','rejected','matchDateRecords','createdDateRecords','excludedAggregateRecords'].map(key=>[key,sources.reduce((n,m)=>n+m.coverage[key],0)])),firstDate:sources.map(m=>m.coverage.firstDate).filter(Boolean).sort()[0]||null,lastDate:sources.map(m=>m.coverage.lastDate).filter(Boolean).sort().at(-1)||null}:null;
 if(coverage)coverage.dateBasis=coverage.matchDateRecords&&coverage.createdDateRecords?'mixed':coverage.createdDateRecords?'record-created-at':'match-date';
 return {id:isAll?'all':'blend:'+chosen.join(','),label:isAll?'Общая мета · 4 лиги':'Выбранная мета · '+chosen.length+' лиги',short:isAll?'Все 4 лиги':sources.map(m=>m.short).join(' + '),metaIds:chosen,composite:true,sources,games:sources.reduce((n,m)=>n+m.games,0),stats,window,coverage,partial:sources.some(m=>m.partial),updated:coverage?.lastDate||null,checked:sources.map(m=>m.checked).sort().at(-1),sourceName:'Объединённая статистика выбранных лиг',source:sources[0].source,note:'Пики, баны и победы суммируются по выбранным лигам. WR = победы / пики; presence = (пики + баны) / число проверенных игр. Нулевая строка означает отсутствие героя в доступной выборке. Покрытие турниров неполное; сохранённые данные не обновляются автоматически.'};
}
const api={normalize,combine};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.MetaPool=api;
})(typeof globalThis!=='undefined'?globalThis:this);
