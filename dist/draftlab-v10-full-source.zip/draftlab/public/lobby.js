(function(root){
'use strict';
const TURN_MS=50000;
const phases=[{mode:'ban',count:3,label:'Баны I'},{mode:'pick',count:3,label:'Пики I'},{mode:'ban',count:2,label:'Баны II'},{mode:'pick',count:2,label:'Пики II'}];
const plan=[];const counts={blue:{ban:0,pick:0},red:{ban:0,pick:0}};
const sequences=[['blue','red','blue','red','blue','red'],['blue','red','red','blue','blue','red'],['red','blue','red','blue'],['red','blue','blue','red']];
phases.forEach((p,phase)=>sequences[phase].forEach(team=>plan.push(Object.freeze({team,mode:p.mode,phase,label:p.label,ordinal:counts[team][p.mode]++}))));
function create(){return {version:2,status:'idle',step:0,actions:[],remainingMs:TURN_MS,deadline:null};}
function current(lobby){return plan[lobby.step]||null;}
function remainingMs(lobby,now=Date.now()){return Math.max(0,Math.min(TURN_MS,lobby.status==='running'?lobby.deadline-now:lobby.remainingMs));}
function start(now=Date.now()){return {...create(),status:'running',deadline:now+TURN_MS};}
function pause(lobby,now=Date.now()){if(lobby.status!=='running')return false;lobby.remainingMs=remainingMs(lobby,now);lobby.deadline=null;lobby.status='paused';return true;}
function resume(lobby,now=Date.now()){if(lobby.status!=='paused')return false;lobby.deadline=now+lobby.remainingMs;lobby.status='running';return true;}
function commit(lobby,heroId,index,now=Date.now(),automatic=false){const turn=current(lobby);if(lobby.status!=='running'||!turn||!heroId||!Number.isInteger(index)||index<0||index>4||(turn.mode==='ban'&&index!==turn.ordinal))return false;lobby.actions.push({...turn,heroId,index,automatic});lobby.step++;lobby.remainingMs=TURN_MS;if(lobby.step===plan.length){lobby.status='complete';lobby.deadline=null;}else lobby.deadline=now+TURN_MS;return true;}
function undo(lobby){const action=lobby.actions.pop();if(!action)return null;lobby.step--;lobby.status='paused';lobby.remainingMs=TURN_MS;lobby.deadline=null;return action;}
function valid(lobby,state){if(!lobby||lobby.version!==2||!['idle','running','paused','complete'].includes(lobby.status)||!Number.isInteger(lobby.step)||lobby.step<0||lobby.step>20||!Array.isArray(lobby.actions)||lobby.actions.length!==lobby.step||!Number.isFinite(lobby.remainingMs)||lobby.remainingMs<0||lobby.remainingMs>TURN_MS)return false;if(lobby.status==='running'&&!Number.isFinite(lobby.deadline))return false;if(lobby.status==='complete'&&lobby.step!==20)return false;if(lobby.status==='idle'&&lobby.step!==0)return false;if(['running','paused'].includes(lobby.status)&&lobby.step===20)return false;const seen=new Set();for(let i=0;i<lobby.actions.length;i++){const a=lobby.actions[i],p=plan[i];if(a.team!==p.team||a.mode!==p.mode||a.phase!==p.phase||a.ordinal!==p.ordinal||!Number.isInteger(a.index)||a.index<0||a.index>4||(p.mode==='ban'&&a.index!==p.ordinal)||seen.has(a.heroId)||state[a.team+(a.mode==='ban'?'Bans':'')][a.index]!==a.heroId)return false;seen.add(a.heroId);}if(lobby.status!=='idle'&&['blue','red','blueBans','redBans'].reduce((n,k)=>n+state[k].filter(Boolean).length,0)!==lobby.actions.length)return false;return true;}
const api={TURN_MS,phases,plan:Object.freeze(plan),create,current,remainingMs,start,pause,resume,commit,undo,valid};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.DraftLobby=api;
})(typeof globalThis!=='undefined'?globalThis:this);
