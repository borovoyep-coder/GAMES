(function(root){
'use strict';
const ROLES=['EXP','JUNGLE','MID','GOLD','ROAM'];
const MISSING_ROLE_PENALTY=.08;
const RATING_DATE='2026-11-08';
const LEAGUE_MULTIPLIERS=Object.freeze({'mpl-id':1.12,'mpl-ph':1.12,'mpl-my':1,mcc:1.10});
// User-requested tuning, separate from measured season form and sourced awards.
const TEAM_ADJUSTMENTS=Object.freeze({'mcc-863a55c78f':Object.freeze({multiplier:1.20,label:'Aurevia Team · общий коэффициент'})});
const PLAYER_ADJUSTMENTS=Object.freeze({'mcc-a36408296d':Object.freeze({multiplier:.90,label:'Juno · общий коэффициент'})});
const SIGNATURE_MULTIPLIER=1.05;
const INTERNATIONAL_POINTS=Object.freeze({wildcard:.5,participation:1,top4:3.5,third:4,runnerup:5,champion:7});
const AWARD_POINTS=Object.freeze({'international-mvp':6,'league-finals-mvp':3,'league-season-mvp':3,'first-team':1,'rookie':1,'most-improved':1});
const INTERNATIONAL_CAP=14,AWARDS_CAP=8;
const round=n=>Math.round((n+Number.EPSILON)*100)/100;
function evidenceScore(items,points){const seen=new Set();return (items||[]).filter(item=>{if(!item.id||seen.has(item.id)||!item.source?.startsWith('https://')||!Number.isFinite(Date.parse(item.date))||item.date>RATING_DATE||!points[item.category])return false;seen.add(item.id);return true;}).map(item=>{const age=Math.max(0,(Date.parse(RATING_DATE)-Date.parse(item.date))/86400000/365.25),decay=Math.pow(.8,age);return {...item,rawPoints:points[item.category],decay:round(decay),points:round(points[item.category]*decay)};});}
function rating(player){
 if(!Number.isFinite(player.formPower))return {version:5,legacy:true,form:player.power,leagueMultiplier:1,leagueBonus:0,international:0,awards:0,total:player.power,internationalEvidence:[],awardEvidence:[]};
 const form=player.formPower,leagueMultiplier=LEAGUE_MULTIPLIERS[player.league]||1,adjustment=PLAYER_ADJUSTMENTS[player.id]||(player.league==='mcc'?TEAM_ADJUSTMENTS[player.teamId]:null),overallMultiplier=adjustment?.multiplier||leagueMultiplier,internationalEvidence=evidenceScore(player.internationalResults,INTERNATIONAL_POINTS),awardEvidence=evidenceScore(player.awards,AWARD_POINTS);
 const internationalRaw=round(internationalEvidence.reduce((s,x)=>s+x.points,0)),awardsRaw=round(awardEvidence.reduce((s,x)=>s+x.points,0)),international=Math.min(INTERNATIONAL_CAP,internationalRaw),awards=Math.min(AWARDS_CAP,awardsRaw),uncapped=round(form*overallMultiplier+international+awards),total=Math.round(Math.min(100,Math.max(0,uncapped))*10)/10;
 return {version:8,date:RATING_DATE,form,leagueMultiplier,overallMultiplier,leagueBonus:round(form*(overallMultiplier-1)),adjustment:adjustment?.label||null,teamMultiplier:1,teamBonus:0,teamAdjustment:null,international,awards,internationalRaw,awardsRaw,internationalEvidence,awardEvidence,uncapped,total,capped:uncapped>100};
}
function signatureFit(ids,pickedHeroes,players){
 const rows=ids.map(id=>players.find(p=>p.id===id)).filter(Boolean).sort((a,b)=>a.id.localeCompare(b.id)),heroes=[...new Map((pickedHeroes||[]).filter(h=>h?.slug).map(h=>[h.slug,h])).values()].sort((a,b)=>a.slug.localeCompare(b.slug));
 if(!heroes.length||heroes.length>rows.length)return {assignments:[],matches:0,confirmedPlayers:rows.filter(p=>p.signatureHeroes?.length).length};
 const baseById=new Map(lineup(ids,players).details.map(p=>[p.id,p.power]));let best=null;
 function visit(index,used,assignments,roleCount,bonus){if(index===heroes.length){if(!best||roleCount>best.roleCount||(roleCount===best.roleCount&&bonus>best.bonus))best={roleCount,bonus,assignments:[...assignments]};return;}
  const hero=heroes[index];for(const player of rows){if(used.has(player.id))continue;const role=normalizeRole(player.role),roleMatch=!!role&&hero.lanes.includes(role),evidence=(player.signatureHeroes||[]).find(s=>s.hero===hero.slug&&s.source?.startsWith('https://liquipedia.net/mobilelegends/')),signature=!!evidence&&roleMatch;used.add(player.id);assignments.push({playerId:player.id,playerName:player.name,hero:hero.slug,heroName:hero.name,role,roleMatch,signature,multiplier:signature?SIGNATURE_MULTIPLIER:1,evidence:evidence||null});visit(index+1,used,assignments,roleCount+(roleMatch?1:0),bonus+(signature?(baseById.get(player.id)||0)*(SIGNATURE_MULTIPLIER-1):0));assignments.pop();used.delete(player.id);}
 }
 visit(0,new Set(),[],0,0);return {assignments:best?.assignments||[],matches:best?.assignments.filter(a=>a.signature).length||0,confirmedPlayers:rows.filter(p=>p.signatureHeroes?.length).length};
}
function applySignatures(line,ids,pickedHeroes,players){const fit=signatureFit(ids,pickedHeroes,players);line.signatureFit=fit;line.withoutSignatures=line.total;for(const detail of line.details){const assignment=fit.assignments.find(a=>a.playerId===detail.id);detail.heroAssignment=assignment||null;detail.preSignaturePower=detail.power;detail.signatureMultiplier=assignment?.multiplier||1;detail.power=round(detail.power*detail.signatureMultiplier);}line.synergyTotal=round(line.details.reduce((sum,p)=>sum+p.power,0));line.total=round(line.synergyTotal*line.roleFit.multiplier);line.rolePenalty=round(line.synergyTotal-line.total);line.signatureBonus=round(line.total-line.withoutSignatures);return line;}
function normalizeRole(value){const key=String(value||'').toUpperCase().replace(/[\s_-]+/g,'');return ({EXP:'EXP',EXPLANER:'EXP',EXPLANE:'EXP',JUNGLE:'JUNGLE',JUNGLER:'JUNGLE',MID:'MID',MIDLANER:'MID',MIDLANE:'MID',GOLD:'GOLD',GOLDLANER:'GOLD',GOLDLANE:'GOLD',ROAM:'ROAM',ROAMER:'ROAM',SUPPORT:'ROAM'})[key]||null;}
function roleFit(rows){const counts=Object.fromEntries(ROLES.map(role=>[role,0]));for(const player of rows){const role=normalizeRole(player.role);if(role)counts[role]++;}const filled=ROLES.filter(role=>counts[role]>0),missing=ROLES.filter(role=>counts[role]===0);return {counts,filled,missing,matched:filled.length,coverage:filled.length/5*100,multiplier:1-MISSING_ROLE_PENALTY*missing.length,duplicates:ROLES.filter(role=>counts[role]>1),unknown:rows.filter(p=>!normalizeRole(p.role)).length};}
function lineup(ids,players){
 const rows=ids.map(id=>players.find(p=>p.id===id)).filter(Boolean);
 const details=rows.map(p=>{const sameTeam=rows.some(q=>q.id!==p.id&&q.teamId===p.teamId),sameRegion=rows.some(q=>q.id!==p.id&&q.region===p.region);const multiplier=sameTeam?1.2:sameRegion?1.1:1,r=rating(p);return {id:p.id,name:p.name,role:normalizeRole(p.role),base:r.total,rating:r,multiplier,power:Math.round(r.total*multiplier*100)/100,reason:sameTeam?'Партнёр из той же команды':sameRegion?'Партнёр из того же региона':'Без бонуса'};});
 const fit=roleFit(rows),synergyTotal=Math.round(details.reduce((s,p)=>s+p.power,0)*100)/100,total=Math.round(synergyTotal*fit.multiplier*100)/100;
 return {total,synergyTotal,base:Math.round(details.reduce((s,p)=>s+p.base,0)*100)/100,roleFit:fit,rolePenalty:Math.round((synergyTotal-total)*100)/100,details};
}
function evaluate(blue,red,players,heroResult=null){
 if(blue.length!==5||red.length!==5||new Set([...blue,...red]).size!==10||[...blue,...red].some(id=>!players.some(p=>p.id===id)))return null;
 const a=lineup(blue,players),b=lineup(red,players);if(heroResult?.a?.team&&heroResult?.b?.team){applySignatures(a,blue,heroResult.a.team,players);applySignatures(b,red,heroResult.b.team,players);}const difference=(a.total-b.total)/5,playerScore=difference*.25;
 const basePlayerScore=(a.synergyTotal-b.synergyTotal)/5*.25,roleScore=(b.rolePenalty-a.rolePenalty)/5*.25;
 const score=heroResult?playerScore*.5+heroResult.score*.5:playerScore;
 const chance=Math.round(Math.max(20,Math.min(80,100/(1+Math.exp(-score/10)))));
 return {blue:chance,red:100-chance,a,b,score,playerScore,basePlayerScore,roleScore,signatureScore:((a.signatureBonus||0)-(b.signatureBonus||0))/5*.25,heroScore:heroResult?.score??null,heroWeight:heroResult ? 0.5 : 0,playerWeight:heroResult ? 0.5 : 1,kind:heroResult?'combined':'players'};
}
const api={ROLES,MISSING_ROLE_PENALTY,RATING_DATE,LEAGUE_MULTIPLIERS,TEAM_ADJUSTMENTS,PLAYER_ADJUSTMENTS,SIGNATURE_MULTIPLIER,INTERNATIONAL_POINTS,AWARD_POINTS,INTERNATIONAL_CAP,AWARDS_CAP,rating,signatureFit,normalizeRole,roleFit,lineup,evaluate};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.PlayerModel=api;
})(typeof globalThis!=='undefined'?globalThis:this);
