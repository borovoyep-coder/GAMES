(function(root){
'use strict';
const ROLES=['EXP','JUNGLE','MID','GOLD','ROAM'];
const OFF_ROLE_POWER=.45;
const VERSION=10;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
// Expert descriptors [frontline, control, early, late, objectives, magic]. Not measured causal effects.
const expert={
'Freya':[6,4,7,8,9,1],'Atlas':[10,10,5,8,4,6],'Hirara':[3,5,8,8,7,2],'Paquito':[6,7,9,5,7,0],'Fanny':[3,3,10,6,8,0],'Marcel':[7,7,6,8,6,5],'Nolan':[3,3,9,6,9,0],'Carmilla':[9,9,6,8,4,7],'Uranus':[10,2,7,7,4,7],'Zhuxin':[3,9,6,9,5,10],'Esmeralda':[8,5,7,7,5,9],'Selena':[2,8,9,5,4,10],'Masha':[8,3,6,9,9,0],'Belerick':[10,9,6,9,4,7],'Aulus':[6,3,4,10,9,0],'Gloo':[10,8,8,7,4,8],'Melissa':[2,5,7,9,9,0],'Barats':[10,8,7,7,8,4],'Eudora':[2,9,9,6,3,10],'Rafaela':[4,6,7,7,3,9],'Obsidia':[3,5,6,9,9,0],'Valentina':[3,8,6,8,4,10],'Claude':[2,3,4,10,9,0],'Alice':[9,7,4,10,6,10],'Mathilda':[4,7,8,6,4,8],'Cici':[6,4,8,7,6,0],'Lylia':[4,6,9,7,5,10],'Minotaur':[10,10,6,8,4,7],'Kimmy':[3,5,8,8,8,9],'Novaria':[2,6,7,8,5,10],'Moskov':[3,7,5,10,10,0],'Lukas':[8,7,8,7,6,2],'Kalea':[8,9,7,8,4,5],'Miya':[2,3,3,10,10,0],'Zetian':[3,8,7,9,5,10],'Brody':[3,6,9,7,7,0],'Gatotkaca':[10,9,6,9,4,7],'Phoveus':[8,8,6,8,5,6],'Arlott':[7,8,8,7,5,0],'Chou':[6,9,8,6,4,0],'Harley':[2,4,9,7,6,10],'Sora':[5,6,8,8,7,1],'Chip':[8,9,8,7,4,6],'Yi Sun-shin':[4,5,6,9,9,1],'Suyou':[6,6,8,7,8,0],'Hylos':[10,7,9,6,4,6],'Ruby':[8,10,7,8,4,0],'Cecilion':[2,7,3,10,5,10],'Alpha':[7,6,8,8,8,1],'Valir':[3,9,9,7,3,10],'Yve':[3,9,7,9,4,10],'Hayabusa':[2,2,7,9,9,0],'Yu Zhong':[9,8,8,7,5,0],'Khufra':[9,10,7,8,4,6],'Diggie':[3,9,8,8,3,8],'Karrie':[3,4,6,10,10,0],'Tigreal':[10,10,6,8,4,5],'Lolita':[8,9,6,8,4,0],'Estes':[4,3,7,9,3,8],'Angela':[3,5,7,9,3,9],'Franco':[9,10,8,7,3,0]};
const counterPairs=[['Diggie','Atlas',5,'Защита от массового контроля'],['Diggie','Tigreal',5,'Защита от массового контроля'],['Khufra','Fanny',4,'Ограничение мобильности'],['Khufra','Nolan',3,'Ограничение рывков'],['Phoveus','Nolan',3,'Ответ на рывки'],['Phoveus','Paquito',3,'Ответ на рывки'],['Karrie','Barats',3,'Урон по прочному фронтлайну'],['Karrie','Belerick',3,'Урон по прочному фронтлайну'],['Belerick','Miya',3,'Ответ на частые автоатаки'],['Belerick','Melissa',2,'Ответ на частые автоатаки'],['Lolita','Kimmy',3,'Защита от снарядов'],['Lolita','Change',3,'Защита от снарядов'],['Esmeralda','Freya',3,'Взаимодействие со щитами'],['Valir','Barats',3,'Дистанция против ближнего фронтлайна'],['Valir','Gloo',3,'Замедления и контроль дистанции'],['Minsitthar','Nolan',4,'Ограничение рывков'],['Franco','Fanny',3,'Точечное подавление']];
function descriptors(h){if(expert[h.name])return expert[h.name];const r=h.role;return [r.includes('Tank')?9:r.includes('Fighter')?6:3,r.includes('Tank')?8:r.includes('Mage')?6:4,r.includes('Assassin')?8:r.includes('Fighter')?7:6,r.includes('Marksman')?9:r.includes('Mage')?8:6,r.includes('Marksman')?9:r.includes('Assassin')?8:4,r.includes('Mage')?10:r.includes('Support')?7:1];}
function autoRoles(team){
 let best={count:-1,assignments:[]};
 function visit(i,used,assignments,count){if(i===team.length){if(count>best.count)best={count,assignments:[...assignments]};return;}
  for(const role of ROLES){if(used.has(role))continue;used.add(role);assignments.push({hero:team[i].slug,role,match:team[i].lanes.includes(role)});visit(i+1,used,assignments,count+(team[i].lanes.includes(role)?1:0));assignments.pop();used.delete(role);}
 }
 visit(0,new Set(),[],0);return best;
}
function metrics(ids,catalog,metaIds){
 const team=ids.map(id=>catalog.find(h=>h.slug===id)).filter(Boolean),n=team.length;
 if(!n)return {team,known:0,assignments:[],meta:50,coverage:0,synergy:0,early:0,mid:0,late:0,magic:0,frontline:0,control:0,objective:0,rolePowerFactor:1};
 const sums=[0,0,0,0,0,0];for(const h of team)descriptors(h).forEach((v,i)=>sums[i]+=v);
 const [tank,cc,early,late,obj,magic]=sums.map(v=>v/n),roleFit=autoRoles(team),known=team.filter(h=>h.stats&&h.stats.picks>0&&h.stats.wr!==null).length;
 const wr=team.reduce((v,h)=>v+(h.stats?.picks>0&&h.stats.wr!==null?(h.stats.wr*h.stats.picks+50*20)/(h.stats.picks+20):50),0)/n;
 const front=clamp(tank/6*100,0,100),control=clamp(cc/7*100,0,100),damageBalance=clamp(100-Math.abs(magic-5)*17,0,100);
 return {team,known,rolePowerFactor:(roleFit.count+OFF_ROLE_POWER*(n-roleFit.count))/n,assignments:roleFit.assignments.map(a=>({...a,powerMultiplier:a.match?1:OFF_ROLE_POWER})),meta:clamp(50+(wr-50)*2.5,0,100),coverage:roleFit.count/5*100,synergy:clamp(front*.3+control*.3+damageBalance*.25+obj*1.5,0,100),early:early*10,mid:(early*.5+late*.3+cc*.2)*10,late:late*10,magic,frontline:front,control,objective:obj*10};
}
function counters(a,b){const an=new Set(a.map(h=>h.name)),bn=new Set(b.map(h=>h.name));return counterPairs.filter(([x,y])=>an.has(x)&&bn.has(y));}
function evaluate(state,catalog,options={}){if(state.blue.length!==5||state.red.length!==5||[...state.blue,...state.red].some(id=>!id))return null;const all=[...state.blue,...state.red];if(new Set(all).size!==10||all.some(id=>!catalog.some(h=>h.slug===id)))return null;const banned=[...state.blueBans,...state.redBans].filter(Boolean);if(all.some(id=>banned.includes(id))||new Set(banned).size!==banned.length)return null;
const metaIds=options.metaIds||state.metaIds;const a=metrics(state.blue,catalog,metaIds),b=metrics(state.red,catalog,metaIds);const ac=counters(a.team,b.team),bc=counters(b.team,a.team);const context=state.context||{};const phase=['early','mid','late'].includes(context.phase)?context.phase:'mid';const rows=[{key:'meta',label:'Турнирная мета',a:a.meta,b:b.meta,weight:.13},{key:'coverage',label:'Соответствие ролям',a:a.coverage,b:b.coverage,weight:.08},{key:'synergy',label:'Баланс состава',a:a.synergy,b:b.synergy,weight:.1},{key:'counter',label:'Контрпики',a:clamp(50+ac.reduce((v,p)=>v+p[2],0)*4,0,100),b:clamp(50+bc.reduce((v,p)=>v+p[2],0)*4,0,100),weight:.1},{key:'phase',label:'Стадия игры',a:context.phase==='balanced'?(a.early+a.mid+a.late)/3:a[phase],b:context.phase==='balanced'?(b.early+b.mid+b.late)/3:b[phase],weight:context.phase==='balanced'?.04:.1}];a.baseStrength=rows.reduce((sum,r)=>sum+r.a*r.weight,0);b.baseStrength=rows.reduce((sum,r)=>sum+r.b*r.weight,0);a.beforeRolePenalty=a.baseStrength;b.beforeRolePenalty=b.baseStrength;a.adjustedStrength=a.baseStrength;b.adjustedStrength=b.baseStrength;a.offRolePenalty=a.beforeRolePenalty*(1-a.rolePowerFactor);b.offRolePenalty=b.beforeRolePenalty*(1-b.rolePowerFactor);a.adjustedStrength-=a.offRolePenalty;b.adjustedStrength-=b.offRolePenalty;rows.push({key:'offrole',label:'Штраф игры вне роли',a:-a.offRolePenalty,b:-b.offRolePenalty,weight:1});rows.forEach(r=>r.delta=(r.a-r.b)*r.weight);const score=rows.reduce((v,r)=>v+r.delta,0);const blue=Math.round(clamp(100/(1+Math.exp(-score/10)),20,80));return {modelVersion:VERSION,blue,red:100-blue,a,b,ac,bc,rows,score,phase};}
function recommendations(state,catalog,selection,options={}){
 const side=selection.team,enemySide=side==='blue'?'red':'blue',metaIds=options.metaIds||state.metaIds;
 const blocked=new Set([...state.blue,...state.red,...state.blueBans,...state.redBans].filter(Boolean));
 const ownIds=[...state[side]];if(selection.mode==='pick')ownIds[selection.index]=null;
 const own=ownIds.map(id=>catalog.find(h=>h.slug===id)).filter(Boolean),enemy=state[enemySide].map(id=>catalog.find(h=>h.slug===id)).filter(Boolean),before=metrics(ownIds,catalog,metaIds);
 return catalog.filter(h=>!blocked.has(h.slug)).map(hero=>{
  if(selection.mode==='ban'){const danger=counters([hero],own);return {hero,score:(hero.stats?.presence||0)+danger.reduce((s,p)=>s+p[2],0)*6,reason:danger.length?'Ответ против '+danger[0][1]+' · экспертная оценка':hero.stats?hero.stats.presence.toFixed(1)+'% presence в выбранной мете':'Нет турнирной выборки'};}
  const ids=[...ownIds];ids[selection.index]=hero.slug;const after=metrics(ids,catalog,metaIds),counter=counters([hero],enemy);
  const score=(after.meta*.30+after.coverage*.28+after.synergy*.22+after.mid*.06+counter.reduce((s,p)=>s+p[2],0)*2+(options.playerHeroBonuses?.[hero.slug]||0))*after.rolePowerFactor;
  let reason=counter.length?'Контрпик к '+counter[0][1]+' · экспертная оценка':after.coverage>before.coverage?'Покрытие ролей +'+Math.round(after.coverage-before.coverage)+' баллов':hero.stats?'Подходит составу · '+hero.stats.picks+' турнирных пиков':'Подходит составу · нет турнирной выборки';
  return {hero,score,reason};
 }).sort((a,b)=>b.score-a.score||a.hero.name.localeCompare(b.hero.name)).slice(0,3);
}
const api={VERSION,ROLES,OFF_ROLE_POWER,autoRoles,descriptors,metrics,evaluate,recommendations,counters};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.DraftModel=api;
})(typeof globalThis!=='undefined'?globalThis:this);
