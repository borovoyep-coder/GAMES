(function(root){
'use strict';
const PLAYER_PICK_ORDER=Object.freeze(['blue','red','red','blue','blue','red','red','blue','blue','red']);
const LEGACY_PLAYER_ORDER=Object.freeze(Array.from({length:10},(_,i)=>i%2?'red':'blue'));
function createGameCore({heroes,metas,players,HeroModel,PlayerModel,Lobby,MetaModel,randomInt}){
 const random=randomInt||((max)=>{const range=4294967296,limit=range-range%max;let n;do{n=crypto.getRandomValues(new Uint32Array(1))[0];}while(n>=limit);return n%max;});
 const empty=()=>({blue:Array(5).fill(null),red:Array(5).fill(null),blueBans:Array(5).fill(null),redBans:Array(5).fill(null),context:{phase:'balanced'}});
 function rolePools(leagues){return Object.fromEntries(PlayerModel.ROLES.map(role=>[role,players.filter(p=>leagues.includes(p.league)&&PlayerModel.normalizeRole(p.role)===role)]));}
 function validateRolePools(leagues){const pools=rolePools(leagues);for(const role of PlayerModel.ROLES)if(pools[role].length<5)throw new Error('Недостаточно игроков '+role+' в выбранных лигах: '+pools[role].length+' из 5');return pools;}
 function drawPool(leagues){const pools=validateRolePools(leagues),result=[];for(const role of PlayerModel.ROLES){const pool=pools[role].map(p=>p.id);for(let i=pool.length-1;i>0;i--){const j=random(i+1);[pool[i],pool[j]]=[pool[j],pool[i]];}result.push(...pool.slice(0,5));}return result;}
 function create({code,userId,nickname,mode,metaId,leagues},now){
  if(!['tournament','players','combined'].includes(mode))throw new Error('Неизвестный режим');
  if(metaId!=='all'&&!metas.some(m=>m.id===metaId))throw new Error('Неизвестный турнир');
  const ls=[...new Set(leagues||[])].filter(l=>['mpl-id','mpl-my','mpl-ph','mcc'].includes(l));if(mode!=='tournament'&&!ls.length)throw new Error('Выберите хотя бы одну лигу');if(mode!=='tournament')validateRolePools(ls);
  return {version:10,playerPickOrder:[...PLAYER_PICK_ORDER],code,mode,metaId:'all',metaIds:metas.map(m=>m.id),leagues:ls,created:now,expires:now+86400000,revision:0,status:'waiting',phase:mode==='tournament'?'heroes':'players',deadline:null,seats:{blue:{userId,nickname,ready:false,rematch:false},red:null},draft:empty(),rosters:{blue:[],red:[]},pool:[],heroStep:0,playerStep:0,log:[],result:null};
 }
 function seat(room,userId){return ['blue','red'].find(s=>room.seats[s]?.userId===userId)||null;}
 function turn(room){if(room.status!=='running')return null;if(room.phase==='players'){const order=room.playerPickOrder||LEGACY_PLAYER_ORDER,team=order[room.playerStep];if(!team)return null;return {team,mode:'player',ordinal:order.slice(0,room.playerStep).filter(side=>side===team).length,label:'Драфт игроков · без банов',phase:-1};}return Lobby.plan[room.heroStep]||null;}
 function start(room,now){room.version=10;room.playerPickOrder=[...PLAYER_PICK_ORDER];room.metaId='all';room.metaIds=metas.map(m=>m.id);if(room.mode!=='tournament')room.pool=drawPool(room.leagues);room.status='running';room.deadline=now+50000;}
 function finish(room){room.status='complete';room.deadline=null;let heroResult=null;if(room.mode!=='players'){const m=MetaModel.combine(metas,room.metaIds||metas.map(m=>m.id));const hs=heroes.map(h=>({...h,stats:m.stats[h.slug]||null}));heroResult=HeroModel.evaluate(room.draft,hs,{metaIds:m.metaIds});if(heroResult)heroResult.metaIds=m.metaIds;if(!heroResult)throw new Error('Неполный драфт героев');}
  const result=room.mode==='tournament'?{...heroResult,kind:'heroes'}:PlayerModel.evaluate(room.rosters.blue,room.rosters.red,players,heroResult);if(!result)throw new Error('Неполный состав');if(room.mode==='combined')result.heroResult=heroResult;room.result=result;
 }
 function available(room,id){if(room.phase==='players')return room.pool.includes(id)&&![...room.rosters.blue,...room.rosters.red].includes(id);return heroes.some(h=>h.slug===id)&&!['blue','red','blueBans','redBans'].some(k=>room.draft[k].includes(id));}
 function pick(room,id,now,automatic=false){const t=turn(room);if(!t||!available(room,id))throw new Error('Этот выбор недоступен');room.log.push({team:t.team,mode:t.mode,ordinal:t.ordinal,id,automatic,at:now});if(room.phase==='players'){
   room.rosters[t.team].push(id);room.playerStep++;if(room.playerStep===10){if(room.mode==='players'){finish(room);return;}room.phase='heroes';}
  }else{room.draft[t.team+(t.mode==='ban'?'Bans':'')][t.ordinal]=id;room.heroStep++;if(room.heroStep===20){finish(room);return;}}
  room.deadline=now+50000;
 }
 function expire(room,now){let changed=false;while(room.status==='running'&&room.deadline<=now){const pool=room.phase==='players'?room.pool.filter(id=>available(room,id)):heroes.filter(h=>available(room,h.slug)).map(h=>h.slug);if(!pool.length)throw new Error('Пустой пул');const at=room.deadline;pick(room,pool[random(pool.length)],at,true);changed=true;}return changed;}
 function command(room,userId,action,body,now){
  if(action==='join'){if(seat(room,userId))return;if(room.seats.red)throw new Error('В комнате уже два участника');if(room.status!=='waiting')throw new Error('Матч уже начался');room.seats.red={userId,nickname:body.nickname,ready:false,rematch:false};return;}
  const side=seat(room,userId);if(!side)throw new Error('Вы не участник этой комнаты');
  if(action==='ready'){if(room.status!=='waiting')throw new Error('Матч уже начался');room.seats[side].ready=true;if(room.seats.blue.ready&&room.seats.red?.ready)start(room,now);return;}
  if(action==='move'){if(room.status!=='running')throw new Error('Сейчас нет активного хода');if(turn(room).team!==side)throw new Error('Сейчас ход соперника');pick(room,body.itemId,now);return;}
  if(action==='rematch'){if(room.status!=='complete')throw new Error('Сначала завершите матч');room.seats[side].rematch=true;if(room.seats.blue.rematch&&room.seats.red.rematch){room.draft=empty();room.rosters={blue:[],red:[]};room.pool=[];room.heroStep=0;room.playerStep=0;room.log=[];room.result=null;room.phase=room.mode==='tournament'?'heroes':'players';for(const s of ['blue','red']){room.seats[s].rematch=false;room.seats[s].ready=true;}start(room,now);}return;}
  throw new Error('Неизвестное действие');
 }
 function botChoice(room,side='red'){
  const t=turn(room);if(!t||t.team!==side)return null;
  if(room.phase==='players'){
   const base=PlayerModel.lineup(room.rosters[side],players).total;
   return room.pool.filter(id=>available(room,id)).map(id=>({id,gain:PlayerModel.lineup([...room.rosters[side],id],players).total-base})).sort((a,b)=>b.gain-a.gain||a.id.localeCompare(b.id))[0]?.id||null;
  }
  const m=MetaModel.combine(metas,room.metaIds||metas.map(m=>m.id)),hs=heroes.map(h=>({...h,stats:m.stats[h.slug]||null}));
  const playerHeroBonuses={};if(room.mode==='combined')for(const id of room.rosters[side]){const player=players.find(p=>p.id===id);for(const signature of player?.signatureHeroes||[]){const hero=heroes.find(h=>h.slug===signature.hero);if(hero?.lanes.includes(PlayerModel.normalizeRole(player.role)))playerHeroBonuses[signature.hero]=5;}}
  return HeroModel.recommendations(room.draft,hs,{team:side,index:t.ordinal,mode:t.mode},{metaIds:m.metaIds,playerHeroBonuses})[0]?.hero.slug||null;
 }
 function snapshot(room,userId,now){if(room.status==='complete'&&room.mode!=='players'&&(room.result?.heroResult||room.result)?.modelVersion!==HeroModel.VERSION){room=structuredClone(room);finish(room);}const side=seat(room,userId);const metaIds=room.metaIds||(room.status==='complete'?[room.metaId]:metas.map(m=>m.id));return {...room,playerPickOrder:room.playerPickOrder||(room.status==='waiting'?PLAYER_PICK_ORDER:LEGACY_PLAYER_ORDER),metaIds,metaId:metaIds.length===metas.length?'all':room.metaId,seats:{blue:room.seats.blue?{nickname:room.seats.blue.nickname,ready:room.seats.blue.ready,rematch:room.seats.blue.rematch}:null,red:room.seats.red?{nickname:room.seats.red.nickname,ready:room.seats.red.ready,rematch:room.seats.red.rematch}:null},side,turn:turn(room),serverNow:now};}
 return {create,seat,turn,pick,expire,command,snapshot,drawPool,rolePools,available,botChoice};
}
const api={PLAYER_PICK_ORDER,createGameCore};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.GameCore=api;
})(typeof globalThis!=='undefined'?globalThis:this);
