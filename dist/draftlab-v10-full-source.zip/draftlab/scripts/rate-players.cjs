// Rebuild ratings from season form and the checked achievement registry.
const fs=require('node:fs'),assert=require('node:assert/strict');
const model=require('../public/player-model.js');
const players=JSON.parse(fs.readFileSync('public/players.json','utf8'));
const registry=JSON.parse(fs.readFileSync('public/player-achievements.json','utf8'));
const signatures=JSON.parse(fs.readFileSync('public/player-signatures.json','utf8'));
const ids=new Set(players.map(p=>p.id));
const heroIds=new Set(JSON.parse(fs.readFileSync('public/heroes.json','utf8')).map(h=>h.slug));
for(const profile of signatures.players){assert.ok(ids.has(profile.playerId));assert.equal(new Set(profile.heroes.map(h=>h.hero)).size,profile.heroes.length);for(const hero of profile.heroes){assert.ok(heroIds.has(hero.hero));assert.ok(hero.source.startsWith('https://liquipedia.net/mobilelegends/'));}}
for(const item of registry.internationalResults.concat(registry.awards)){
 assert.ok(ids.has(item.playerId),'Unknown player '+item.playerId);
 assert.ok(item.source.startsWith('https://'));
 assert.ok(item.date<=model.RATING_DATE);
}
for(const player of players){
 player.formPower??=player.power;
 player.signatureHeroes=signatures.players.find(x=>x.playerId===player.id)?.heroes||[];
 player.signatureStatus=player.signatureHeroes.length?'confirmed-partial':'unconfirmed';
 player.internationalResults=registry.internationalResults.filter(x=>x.playerId===player.id).map(({playerId,...x})=>x);
 player.awards=registry.awards.filter(x=>x.playerId===player.id).map(({playerId,...x})=>x);
 player.rating=model.rating(player);
 player.power=player.rating.total;
}
fs.writeFileSync('public/players.json',JSON.stringify(players));
console.log(JSON.stringify({players:players.length,internationalPlayers:players.filter(p=>p.internationalResults.length).length,awardPlayers:players.filter(p=>p.awards.length).length,awards:registry.awards.length,date:model.RATING_DATE}));
