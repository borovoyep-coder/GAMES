const assert=require('node:assert/strict'),fs=require('node:fs');
const HM=require('../public/model.js'),PM=require('../public/player-model.js'),Lobby=require('../public/lobby.js'),MetaModel=require('../public/meta-pool.js'),heroes=require('../public/heroes.json'),players=require('../public/players.json'),metas=require('../public/metas.json');
assert.equal(HM.VERSION,10);assert.equal(HM.teamPairs,undefined);assert.equal(HM.pairStats,undefined);assert.equal(HM.pairData,undefined);assert.equal(fs.existsSync('public/hero-pairs.json'),false);
const state={blue:['harith','grock','lancelot','estes','karina'],red:['hanabi','akai','change','miya','thamuz'],blueBans:[],redBans:[],context:{phase:'balanced'}};
const result=HM.evaluate(state,heroes);assert.equal(result.modelVersion,10);assert.ok(!result.rows.some(r=>r.key==='pairs'));assert.deepEqual(result.rows.map(r=>r.key),['meta','coverage','synergy','counter','phase','offrole']);
for(const side of ['a','b']){const line=result[side];assert.equal(line.pairBonus,undefined);assert.equal(line.pairInfo,undefined);assert.ok(Math.abs(line.adjustedStrength-line.baseStrength*line.rolePowerFactor)<1e-10);const weighted=result.rows.filter(r=>r.key!=='offrole').reduce((sum,r)=>sum+r[side]*r.weight,0);assert.ok(Math.abs(line.baseStrength-weighted)<1e-10);}
assert.ok(Math.abs(result.score-(result.a.adjustedStrength-result.b.adjustedStrength))<1e-10);assert.equal(result.blue+result.red,100);
const swapped=HM.evaluate({...state,blue:state.red,red:state.blue},heroes);assert.equal(swapped.blue,result.red);
assert.equal(HM.evaluate({...state,blueBans:['grock']},heroes),null);
for(const team of ['blue','red']){const recommendations=HM.recommendations(state,heroes,{team,index:1,mode:'pick'});assert.equal(recommendations.length,3);assert.ok(recommendations.every(r=>!/[Сс]вязк|дуэт|парный/.test(r.reason)));}
const core=require('../public/game-core.js').createGameCore({heroes,players,metas,HeroModel:HM,PlayerModel:PM,Lobby,MetaModel,randomInt:n=>n-1});
for(const mode of ['tournament','combined']){
 const room=core.create({code:'ABC2345',userId:'blue',nickname:'Blue',mode,metaId:'all',leagues:metas.map(m=>m.id)},1000);core.command(room,'red','join',{nickname:'Red'},1000);core.command(room,'blue','ready',{},1000);core.command(room,'red','ready',{},1000);core.expire(room,1000+50000*(mode==='combined'?30:20));assert.equal(room.status,'complete');const heroResult=room.result.heroResult||room.result;assert.equal(heroResult.modelVersion,10);assert.ok(!heroResult.rows.some(r=>r.key==='pairs'));
 // Old completed rooms are recalculated for display without rewriting the stored archive.
 const old=structuredClone(room);const oldHero=old.result.heroResult||old.result;oldHero.modelVersion=8;oldHero.rows.push({key:'pairs',label:'Связки героев',a:8,b:0,weight:1,delta:8});oldHero.score+=8;const prior=JSON.stringify(old);const view=core.snapshot(old,'blue',2000000),visibleHero=view.result.heroResult||view.result;assert.equal(visibleHero.modelVersion,10);assert.ok(!visibleHero.rows.some(r=>r.key==='pairs'));assert.equal(JSON.stringify(old),prior);assert.equal(view.seats.blue.userId,undefined);
}
console.log('PASS: no pair data, multipliers, score rows or advisor reasons; raw weighted strength and role penalties remain exact; both hero modes and old-room display use the current calculation.');
