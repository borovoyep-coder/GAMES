const assert=require('node:assert/strict');
const PM=require('../public/player-model.js'),HM=require('../public/model.js'),Lobby=require('../public/lobby.js'),MetaModel=require('../public/meta-pool.js');
const {createGameCore}=require('../public/game-core.js');
const heroes=require('../public/heroes.json'),metas=require('../public/metas.json'),players=require('../public/players.json'),registry=require('../public/player-achievements.json');
const core=createGameCore({heroes,metas,players,HeroModel:HM,PlayerModel:PM,Lobby,MetaModel,randomInt:n=>n-1});
function start(mode){const r=core.create({code:'ABC2345',userId:'A',nickname:'Blue',mode,metaId:'all',leagues:metas.map(m=>m.id)},1000);core.command(r,'B','join',{nickname:'Red'},1000);core.command(r,'A','ready',{},1000);core.command(r,'B','ready',{},1000);return r;}
const order='BRRBBRRBBR';
for(const mode of ['players','combined']){
 const room=start(mode);assert.equal(room.pool.length,25);assert.equal(new Set(room.pool).size,25);
 for(const role of PM.ROLES)assert.equal(room.pool.filter(id=>players.find(p=>p.id===id).role===role).length,5);
 const ordinals={blue:0,red:0};
 for(let i=0;i<10;i++){
  const turn=core.turn(room),team=order[i]==='B'?'blue':'red';assert.equal(turn.team,team);assert.equal(turn.ordinal,ordinals[team]++);assert.equal(turn.mode,'player');
  const before=room.deadline,id=room.pool.find(id=>core.available(room,id));
  assert.throws(()=>core.command(room,team==='blue'?'B':'A','move',{itemId:id},1001+i),/ход соперника/);
  core.command(room,team==='blue'?'A':'B','move',{itemId:id},1001+i);
  if(room.status==='running')assert.equal(room.deadline,51001+i);
  assert.ok(before>1001+i);
 }
 assert.equal(room.rosters.blue.length,5);assert.equal(room.rosters.red.length,5);
 assert.equal(room.log.map(x=>x.team[0].toUpperCase()).join(''),order);
 assert.ok(room.log.every(x=>x.mode==='player'));assert.ok(room.draft.blueBans.every(x=>x===null));assert.ok(room.draft.redBans.every(x=>x===null));
 if(mode==='combined'){
  assert.equal(room.phase,'heroes');assert.equal(room.heroStep,0);
  assert.equal(core.turn(room).mode,'ban');assert.equal(core.turn(room).team,'blue');
  core.expire(room,room.deadline+19*50000);
  assert.deepEqual(room.log.slice(10).map(x=>[x.team,x.mode,x.ordinal]),Lobby.plan.map(x=>[x.team,x.mode,x.ordinal]));
 }
 assert.equal(room.status,'complete');assert.equal(room.result.blue+room.result.red,100);
 assert.ok(room.result.a.details.every(d=>d.rating.version===8&&d.base===d.rating.total));
 assert.ok(room.result.a.roleFit);assert.ok(room.result.b.roleFit);
 core.command(room,'A','rematch',{},2000000);core.command(room,'B','rematch',{},2000000);assert.equal(core.turn(room).team,'blue');assert.equal(room.playerStep,0);assert.equal(room.log.length,0);
}
const timed=start('players');core.expire(timed,501000);assert.equal(timed.status,'complete');assert.equal(timed.log.map(x=>x.team[0].toUpperCase()).join(''),order);assert.ok(timed.log.every(x=>x.automatic));assert.deepEqual(timed.log.map(x=>x.at),Array.from({length:10},(_,i)=>51000+i*50000));
const legacy=start('players');delete legacy.playerPickOrder;legacy.version=5;core.expire(legacy,501000);assert.equal(legacy.log.map(x=>x.team[0].toUpperCase()).join(''),'BRBRBRBRBR');assert.equal(core.snapshot(legacy,'A',501000).playerPickOrder.map(x=>x[0].toUpperCase()).join(''),'BRBRBRBRBR');core.command(legacy,'A','rematch',{},600000);core.command(legacy,'B','rematch',{},600000);assert.equal(legacy.playerPickOrder.map(x=>x[0].toUpperCase()).join(''),order);
const ordinary={formPower:60,league:'mpl-my'},id={...ordinary,league:'mpl-id'},ph={...ordinary,league:'mpl-ph'};
assert.equal(PM.rating(id).total,67.2);assert.equal(PM.rating(ph).total,67.2);assert.equal(PM.rating(ordinary).total,60);assert.equal(PM.rating({...ordinary,league:'mcc'}).total,66);
const event={id:'test-event',event:'Test international',date:PM.RATING_DATE,category:'champion',source:'https://example.com/result'};
const champ={...ordinary,internationalResults:[event]};assert.equal(PM.rating(champ).total,67);assert.equal(PM.rating({...champ,internationalResults:[event,event]}).total,67);assert.equal(PM.rating({...champ,internationalResults:[{...event,category:'participation'}]}).total,61);assert.ok(PM.rating({...champ,internationalResults:[{...event,date:'2021-01-24'}]}).international<7);
assert.equal(PM.rating({...champ,internationalResults:[{...event,date:'2027-01-01'}]}).international,0);assert.equal(PM.rating({...champ,internationalResults:[{...event,source:''}]}).international,0);
const award={...event,id:'test-mvp',category:'international-mvp'};assert.equal(PM.rating({...ordinary,awards:[award]}).total,66);assert.equal(PM.rating({...ordinary,awards:[award,award]}).awards,6);
const capped=PM.rating({...id,formPower:95,internationalResults:[event,{...event,id:'event2'},{...event,id:'event3'}],awards:[award,{...award,id:'award2'}]});assert.equal(capped.international,14);assert.equal(capped.awards,8);assert.equal(capped.total,100);assert.equal(capped.capped,true);
for(const p of players){assert.equal(p.power,PM.rating(p).total);assert.ok(p.power>=0&&p.power<=100);assert.equal(new Set(p.internationalResults.map(x=>x.id)).size,p.internationalResults.length);assert.equal(new Set(p.awards.map(x=>x.id)).size,p.awards.length);assert.ok(p.internationalResults.concat(p.awards).every(x=>x.source.startsWith('https://')&&x.date<=PM.RATING_DATE));}
assert.equal(players.length,207);assert.equal(registry.internationalEvents.length,11);assert.equal(registry.awards.length,30);
const transferred=players.find(p=>p.name==='DEMONKITE');assert.equal(transferred.league,'mpl-id');assert.ok(transferred.internationalResults.some(x=>x.id==='m7-world-championship'&&x.category==='champion'&&x.team==='Aurora Gaming PH'));
assert.ok(players.find(p=>p.name==='Light').awards.some(x=>x.event==='M7 World Championship'));
assert.ok(players.find(p=>p.name==='Kid Bomba').awards.some(x=>x.event==='MSC 2026'));
const roster=PM.ROLES.map((role,i)=>({id:'a'+i,name:'A'+i,role,teamId:'T'+i,region:'R'+i,...ordinary}));const stronger=roster.map((p,i)=>({...p,id:'b'+i,teamId:'X'+i,region:'Z'+i,league:'mpl-ph'}));const result=PM.evaluate(roster.map(p=>p.id),stronger.map(p=>p.id),[...roster,...stronger]);assert.ok(result.red>50);const combined=PM.evaluate(roster.map(p=>p.id),stronger.map(p=>p.id),[...roster,...stronger],{score:0});assert.ok(combined.red>50);assert.equal(combined.playerScore,result.playerScore);
console.log('PASS: exact pick-only order, every pick has 50 seconds, opponent rejection, both modes, hero-stage transition, timeouts, legacy/rematch compatibility, league strength, sourced achievements, recency, deduplication, caps, transfer identity, and ratings affect both outcomes.');
