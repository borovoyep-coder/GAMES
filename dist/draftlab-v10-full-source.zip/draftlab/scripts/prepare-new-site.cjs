// Export-only helper: remove the old hosting identity before a new-account deployment.
// Does not contact Sites, edit the original repository, or delete any application data.
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),manifestPath=path.join(root,'.openai','hosting.json');
const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
const originalId='appgprj_6af045c96fb08191b5b96cfe53ca4341';
if(manifest.project_id&&manifest.project_id!==originalId){
 console.error('В этой копии уже настроен другой проект Sites. Его ID не изменён.');
 process.exit(1);
}
delete manifest.project_id;
fs.writeFileSync(manifestPath,JSON.stringify(manifest,null,2)+'\n');
// Remove only known generated output, whose hosting manifest can contain the old ID.
const compiled=path.join(root,'dist','server','index.js');
const compiledManifest=path.join(root,'dist','.openai','hosting.json');
for(const file of [compiled,compiledManifest])if(fs.existsSync(file))fs.unlinkSync(file);
console.log('Копия подготовлена для НОВОГО сайта. Создайте проект Sites в целевом аккаунте.');
console.log('Сохраните возвращённый project_id в .openai/hosting.json, оставив r2: "BUCKET" и d1: null.');
console.log('После регистрации соберите: node scripts/build.mjs. Полная инструкция: START_HERE.md.');
