const assert=require('node:assert/strict');
const HM=require('../public/model.js'),PM=require('../public/player-model.js'),Lobby=require('../public/lobby.js'),MetaModel=require('../public/meta-pool.js'),heroes=require('../public/heroes.json'),players=require('../public/players.json'),metas=require('../public/metas.json');
const core=require('../public/game-core.js').createGameCore({heroes,players,metas,HeroModel:HM,PlayerModel:PM,Lobby,MetaModel,randomInt:n=>n-1});
class Bucket{constructor(){this.objects=new Map();this.revision=0;}async get(key){const value=this.objects.get(key);return value?{etag:value.etag,json:async()=>JSON.parse(value.body)}:null;}async head(key){return this.objects.get(key)||null;}async put(key,body,options={}){const old=this.objects.get(key),condition=options.onlyIf||{};if(condition.etagMatches&&condition.etagMatches!==old?.etag)return null;if(condition.etagDoesNotMatch==='*'&&old)return null;const etag=String(++this.revision);this.objects.set(key,{body,etag});return {etag};}}
let time=1000000,index=0;const bucket=new Bucket(),codes=['ABC2345','BCD3456','CDE4567','DEF5678'];
const server=require('../worker/server-core.js').makeServer({core,assets:{},now:()=>time,newCode:()=>codes[index++]});
async function request(cookie,path,body,headers={}){const response=await server.fetch(new Request('https://test.local'+path,{method:body!==undefined?'POST':'GET',headers:{...(cookie?{cookie}:{}),...(body!==undefined?{'Content-Type':'application/json','X-Draftlab-Request':'1',Origin:'https://test.local'}:{}),...headers},...(body!==undefined?{body:JSON.stringify(body)}:{})}),{BUCKET:bucket});return {status:response.status,body:await response.json(),cookie:response.headers.get('set-cookie')};}
(async()=>{
 assert.equal((await request(null,'/api/rooms',{})).status,401);
 assert.equal((await request(null,'/api/guest',{},OriginHeader('https://evil.local'))).status,403);
 assert.equal((await request(null,'/api/guest',{}, {'X-Draftlab-Request':''})).status,403);
 assert.equal((await request(null,'/api/guest')).status,405);
 const a=await request(null,'/api/guest',{}),b=await request(null,'/api/guest',{}),c=await request(null,'/api/guest',{});assert.equal(a.status,201);assert.equal(b.status,201);assert.notEqual(a.cookie,b.cookie);assert.match(a.cookie,/^__Host-draftlab_guest=[a-f0-9]{64}; Path=\/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800$/);assert.deepEqual(a.body,{canPlay:true,guest:true,signedIn:false});
 const ca=a.cookie.split(';')[0],cb=b.cookie.split(';')[0],cc=c.cookie.split(';')[0];
 assert.deepEqual((await request(ca,'/api/me')).body,{signedIn:false,guest:true,canPlay:true});assert.equal((await request(ca,'/api/guest',{})).cookie,null);
 assert.equal((await request('__Host-draftlab_guest='+'a'.repeat(64),'/api/me')).status,401);
 let result=await request(ca,'/api/rooms',{mode:'tournament',metaId:'all',leagues:[],nickname:'Blue guest'});assert.equal(result.status,201);let room=result.body.room;const code=room.code;assert.equal(room.seats.blue.userId,undefined);assert.equal(room.side,'blue');
 assert.equal((await request(cb,'/api/rooms/'+code)).status,403);assert.equal((await request(ca,'/api/rooms/'+code+'/join',{nickname:'Again'})).body.room.side,'blue');
 result=await request(cb,'/api/rooms/'+code+'/join',{nickname:'Red guest'});assert.equal(result.status,200);assert.equal(result.body.room.side,'red');assert.equal((await request(cc,'/api/rooms/'+code+'/join',{nickname:'Third'})).status,400);assert.equal((await request(cc,'/api/rooms/'+code)).status,403);
 await request(ca,'/api/rooms/'+code+'/ready',{});room=(await request(cb,'/api/rooms/'+code+'/ready',{})).body.room;assert.equal(room.status,'running');
 const candidate=r=>heroes.find(h=>core.available(r,h.slug)).slug;
 assert.equal((await request(cb,'/api/rooms/'+code+'/move',{revision:room.revision,itemId:candidate(room)})).status,400);
 const move={revision:room.revision,itemId:candidate(room)},race=await Promise.all([request(ca,'/api/rooms/'+code+'/move',move),request(ca,'/api/rooms/'+code+'/move',move)]);assert.equal(race.filter(r=>r.status===200).length,1);assert.equal(race.filter(r=>r.status===409).length,1);
 room=(await request(ca,'/api/rooms/'+code)).body.room;
 while(room.status==='running'){const turn=room.turn;assert.deepEqual([turn.team,turn.mode],[Lobby.plan[room.heroStep].team,Lobby.plan[room.heroStep].mode]);result=await request(turn.team==='blue'?ca:cb,'/api/rooms/'+code+'/move',{revision:room.revision,itemId:candidate(room)});assert.equal(result.status,200);room=result.body.room;}
 assert.equal(room.log.length,20);assert.equal(room.result.blue+room.result.red,100);assert.ok(room.result.rows.some(r=>r.key==='offrole'));
 assert.equal((await request(ca,'/api/rooms/'+code)).body.room.status,'complete');
 for(const [key,value] of bucket.objects){for(const cookie of [ca,cb,cc]){const raw=cookie.split('=')[1];assert.ok(!key.includes(raw));assert.ok(!value.body.includes(raw));}}
 const native=await request(null,'/api/rooms',{mode:'players',metaId:'all',leagues:['mcc'],nickname:'Native compatibility'},{'oai-authenticated-user-id':'native-user'});assert.equal(native.status,201);
 time+=7*86400000+1;assert.equal((await request(ca,'/api/me')).status,401);assert.equal((await request(null,'/api/guest',{})).status,201);
 console.log('PASS: two guests complete an online tournament without GPT registration; HttpOnly sessions, hashed storage, forged/expired-cookie rejection, CSRF, seat privacy, third-user rejection, server turn order, replay/CAS protection, reload and native identity compatibility.');
})().catch(error=>{console.error(error);process.exitCode=1;});
function OriginHeader(origin){return {Origin:origin};}
