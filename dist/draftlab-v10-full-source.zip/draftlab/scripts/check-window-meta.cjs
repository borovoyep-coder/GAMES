const assert=require('node:assert/strict'),fs=require('node:fs');
const {build,recordDate}=require('./build-window-meta.cjs'),MP=require('../public/meta-pool.js'),HM=require('../public/model.js'),PM=require('../public/player-model.js'),Lobby=require('../public/lobby.js');
const input=require('../public/meta-matches.json'),H=require('../public/heroes.json'),P=require('../public/players.json'),M=require('../public/metas.json'),audit=require('../public/meta-audit.json');
const result=build(input,H),total=M.reduce((n,m)=>n+m.games,0);
assert.deepEqual(result.metas,M,'Checked-in meta must reproduce from the public source records');
assert.deepEqual(result.audit,audit.rejectedRecords);assert.equal(total,350);assert.equal(input.records.length,359);assert.equal(audit.rejectedRecords.length,9);
assert.deepEqual(input.window,{from:'2026-09-08',to:'2026-11-08',timezone:'Europe/Moscow',inclusive:true});
assert.deepEqual(Object.fromEntries(M.map(m=>[m.id,m.games])),{'mpl-id':114,'mpl-my':100,'mpl-ph':116,mcc:20});
assert.equal(M.find(m=>m.id==='mcc').coverage.excludedAggregateRecords,135);
for(const m of M){
 assert.equal(m.coverage.completeTournament,false);assert.equal(m.partial,false);assert.equal(m.games,m.coverage.accepted);assert.equal(m.coverage.candidates-m.games,m.coverage.rejected);
 const rows=Object.values(m.stats);assert.equal(rows.reduce((n,r)=>n+r.picks,0),10*m.games);assert.equal(rows.reduce((n,r)=>n+r.wins,0),5*m.games);assert.equal(rows.reduce((n,r)=>n+r.bans,0),10*m.games);
 for(const r of rows){assert.ok(Number.isInteger(r.wins)&&r.wins<=r.picks);assert.equal(r.sampleGames,m.games);assert.ok(r.presence>=0&&r.presence<=100);assert.ok(Math.abs(r.presence-(r.picks+r.bans)/m.games*100)<.000001);if(r.picks)assert.ok(Math.abs(r.wr-r.wins/r.picks*100)<.000001);else assert.equal(r.wr,null);for(const role of Object.values(r.roles))assert.ok(role.picks<=r.picks&&role.wins<=r.wins);}
 assert.equal(m.coverage.dateBasis,m.id==='mcc'?'match-date':'record-created-at');
}
// Every nonempty free-draft subset uses exactly its own counts and denominator.
for(let mask=1;mask<16;mask++){
 const selected=M.filter((m,i)=>mask&(1<<i)),mix=MP.combine(M,selected.map(m=>m.id)),games=selected.reduce((n,m)=>n+m.games,0);
 assert.equal(mix.games,games);assert.deepEqual(mix.window,input.window);assert.equal(mix.coverage.accepted,games);
 for(const [hero,row] of Object.entries(mix.stats)){
  assert.equal(row.picks,selected.reduce((n,m)=>n+(m.stats[hero]?.picks||0),0));assert.equal(row.bans,selected.reduce((n,m)=>n+(m.stats[hero]?.bans||0),0));assert.equal(row.wins,selected.reduce((n,m)=>n+(m.stats[hero]?.wins||0),0));assert.equal(row.sampleGames,games);
  if(row.picks)assert.ok(Math.abs(row.wr-row.wins/row.picks*100)<.000001);
 }
}
assert.throws(()=>MP.combine(M,[]),/хотя бы одну/);assert.equal(MP.combine(M,['mcc','mcc']).metaIds.length,1);
// Legacy sparse snapshots retain their known-coverage semantics.
const legacy=MP.combine([{id:'a',short:'A',games:10,stats:{freya:{picks:2,bans:1,wr:50}}},{id:'b',short:'B',games:5,stats:{},partial:true}],['a','b']);assert.equal(legacy.stats.freya.sampleGames,10);assert.equal(legacy.stats.freya.wins,1);
const tz=input.window.timezone;
for(const [recordedAt,date] of [['2026-09-07T20:59:59Z','2026-09-07'],['2026-09-07T21:00:00Z','2026-09-08'],['2026-11-08T20:59:59Z','2026-11-08'],['2026-11-08T21:00:00Z','2026-11-09']])assert.deepEqual(recordDate({recordedAt},tz),{date,basis:'record-created-at'});
assert.deepEqual(recordDate({matchDate:'2026-10-01',recordedAt:'2026-11-09T00:00:00Z'},tz),{date:'2026-10-01',basis:'match-date'});
assert.equal(recordDate({matchDate:'2026-02-30',recordedAt:'2026-10-01T00:00:00Z'},tz),null);assert.equal(recordDate({recordedAt:'bad-date'},tz),null);
// Dates, completion and draft validity are enforced before any count contributes.
const seed=structuredClone(input.records.find(r=>!result.audit.some(a=>a.id===r.id)));let serial=0;
const record=changes=>({...structuredClone(seed),id:'fixture-'+(++serial),league:'mpl-id',matchDate:'2026-10-01',recordedAt:null,...changes});
const first=record({matchDate:null,recordedAt:'2026-09-07T21:00:00Z'}),last=record({matchDate:null,recordedAt:'2026-11-08T20:59:59Z'});
const pickedBan=record({});pickedBan.blueBans[0]=pickedBan.blue[0].hero;
const duplicatePick=record({});duplicatePick.red[0].hero=duplicatePick.blue[0].hero;
const duplicateBan=record({});duplicateBan.redBans[0]=duplicateBan.blueBans[0];
const unknown=record({});unknown.blue[0].hero='not-a-hero';
const fixture=build({...input,records:[first,last,structuredClone(first),record({matchDate:null,recordedAt:'2026-09-07T20:59:59Z'}),record({matchDate:null,recordedAt:'2026-11-08T21:00:00Z'}),record({winner:null}),record({mode:'brawl'}),record({matchDate:null}),record({blue:[]}),record({league:'other'}),pickedBan,duplicatePick,duplicateBan,unknown],excludedSourceGroups:[]},H);
assert.equal(fixture.summary.totalGames,2);assert.equal(fixture.audit.length,12);
for(const reason of ['duplicate-id','outside-window','invalid-winner','wrong-mode','missing-or-invalid-date','incomplete-draft','unknown-league','picked-and-banned','duplicate-pick','duplicate-ban','unknown-hero'])assert.ok(fixture.audit.some(r=>r.reason===reason),reason);
const mix=MP.combine(M,M.map(m=>m.id)),catalog=H.map(h=>({...h,stats:mix.stats[h.slug]||null}));
const core=require('../public/game-core.js').createGameCore({heroes:H,players:P,metas:M,HeroModel:HM,PlayerModel:PM,Lobby,MetaModel:MP,randomInt:n=>n-1});
for(const mode of ['tournament','combined']){
 const room=core.create({code:'ABC2345',userId:'blue',nickname:'Blue',mode,metaId:'mpl-id',leagues:M.map(m=>m.id)},1000);core.command(room,'red','join',{nickname:'Red'},1000);core.command(room,'blue','ready',{},1000);core.command(room,'red','ready',{},1000);core.expire(room,1000+50000*(mode==='combined'?30:20));
 assert.equal(room.status,'complete');assert.equal(room.metaIds.length,4);const r=room.result.heroResult||room.result,manual=HM.evaluate(room.draft,catalog,{metaIds:mix.metaIds});assert.equal(r.modelVersion,10);assert.equal(r.score,manual.score);assert.equal(r.blue,manual.blue);assert.ok(!r.rows.some(row=>row.key==='pairs'));
 const old=structuredClone(room);(old.result.heroResult||old.result).modelVersion=9;(old.result.heroResult||old.result).score=999;const archive=JSON.stringify(old),view=core.snapshot(old,'blue',2000000);assert.equal((view.result.heroResult||view.result).score,manual.score);assert.equal((view.result.heroResult||view.result).modelVersion,10);assert.equal(JSON.stringify(old),archive);
}
assert.equal(fs.existsSync('public/hero-pairs.json'),false);
console.log('PASS: reproducible 350-game two-month meta, explicit ingestion/date coverage, 9 invalid drafts and 135 undated MCC games excluded, exact wins and all 15 league subsets, Moscow boundaries, validation failures, legal competitive modes and old-room rescoring without hero pair bonuses.');
