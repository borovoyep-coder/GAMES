(function(root){
'use strict';
function makeServer({core,assets,now=()=>Date.now(),newCode}){
 const json=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
 const COOKIE='__Host-draftlab_guest',SESSION_MS=7*86400000;
 const hex=bytes=>Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');
 const tokenHash=async token=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token))));
 async function identity(request,bucket){const native=request.headers.get('oai-authenticated-user-id');if(native)return {userId:native,guest:false};const token=(request.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(COOKIE+'='))?.slice(COOKIE.length+1);if(!token||!/^[a-f0-9]{64}$/.test(token)||!bucket)return null;const hash=await tokenHash(token),record=await bucket.get('guest-sessions/v1/'+hash);if(!record)return null;const session=await record.json();return session.expires>now()?{userId:'guest:'+hash,guest:true}:null;}
 const nickname=v=>String(v||'Участник').trim().slice(0,32)||'Участник';
 const codeOK=c=>/^[A-HJ-NP-Z2-9]{7}$/.test(c);
 async function load(bucket,code){const object=await bucket.get('rooms/v3/'+code);if(!object)return null;return {room:await object.json(),etag:object.etag};}
 async function update(bucket,code,userId,action,body){
  for(let attempt=0;attempt<5;attempt++){
   const item=await load(bucket,code);if(!item)return json({error:'Комната не найдена или срок её действия истёк'},404);
   const {room,etag}=item,time=now();if(room.expires<time)return json({error:'Срок комнаты истёк. Создайте новую.'},410);
   const participant=core.seat(room,userId);if(!participant&&action!=='join')return json({error:'Присоединитесь к комнате по коду'},403);if(!participant&&action==='join'&&room.seats.red)return json({error:'В комнате уже два участника'},400);
   let expired=core.expire(room,time);if(expired){room.revision++;const wrote=await bucket.put('rooms/v3/'+code,JSON.stringify(room),{onlyIf:{etagMatches:etag},httpMetadata:{contentType:'application/json'}});if(!wrote)continue;if(action==='read')return json({room:core.snapshot(room,userId,time)});return json({error:'Время хода истекло. Состояние обновлено.',room:core.snapshot(room,userId,time)},409);}
   if(action==='read')return json({room:core.snapshot(room,userId,time)});
   if(action==='move'&&body.revision!==room.revision)return json({error:'Ход уже изменился. Выберите вариант заново.',room:core.snapshot(room,userId,time)},409);
   try{core.command(room,userId,action,{...body,nickname:nickname(body.nickname)},time);}catch(e){return json({error:e.message,room:participant?core.snapshot(room,userId,time):undefined},400);}
   room.revision++;let wrote;
   try{wrote=await bucket.put('rooms/v3/'+code,JSON.stringify(room),{onlyIf:{etagMatches:etag},httpMetadata:{contentType:'application/json'}});}catch(e){if(e?.status===412||String(e.message).includes('precondition'))continue;throw e;}
   if(!wrote)continue;return json({room:core.snapshot(room,userId,time)});
  }
  return json({error:'Состояние меняется. Повторите действие.'},409);
 }
 async function handle(request,env){
  const url=new URL(request.url),path=url.pathname;
  if(path==='/api/health'){if(!env.BUCKET)return json({ok:false,error:'Хранилище комнат не подключено'},503);await env.BUCKET.head('health-check');return json({ok:true,storage:'ready',version:10});}
  if(path.startsWith('/api/')){
   const bucket=env.BUCKET;if(!bucket)return json({error:'Сетевое хранилище ещё не подключено'},503);
   if(!['GET','POST'].includes(request.method))return json({error:'Метод недоступен'},405);
   let body={};if(request.method==='POST'){
    if(request.headers.get('x-draftlab-request')!=='1'||request.headers.get('sec-fetch-site')==='cross-site'||(request.headers.get('origin')&&request.headers.get('origin')!==url.origin)||!request.headers.get('content-type')?.includes('application/json'))return json({error:'Запрос должен прийти из приложения'},403);
    const text=await request.text();if(text.length>8192)return json({error:'Слишком большой запрос'},413);try{body=JSON.parse(text);}catch{return json({error:'Неверный JSON'},400);}if(!body||typeof body!=='object'||Array.isArray(body))return json({error:'Неверный запрос'},400);
   }
   const visitor=await identity(request,bucket);
   if(path==='/api/guest'){
    if(request.method!=='POST')return json({error:'Метод недоступен'},405);
    if(visitor)return json({canPlay:true,guest:visitor.guest,signedIn:!visitor.guest});
    for(let attempt=0;attempt<3;attempt++){const token=hex(crypto.getRandomValues(new Uint8Array(32))),hash=await tokenHash(token),created=now();const written=await bucket.put('guest-sessions/v1/'+hash,JSON.stringify({created,expires:created+SESSION_MS}),{onlyIf:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json'}});if(written)return json({canPlay:true,guest:true,signedIn:false},201,{'Set-Cookie':COOKIE+'='+token+'; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800'});}
    return json({error:'Не удалось открыть гостевой доступ. Повторите.'},503);
   }
   if(!visitor)return json({error:'Откройте гостевой доступ для сетевой игры',guestSessionRequired:true},401);
   const userId=visitor.userId;
   if(path==='/api/me'&&request.method==='GET')return json({signedIn:!visitor.guest,guest:visitor.guest,canPlay:true});
   if(path==='/api/rooms'&&request.method==='POST'){
    let room;const code=newCode();try{room=core.create({code,userId,nickname:nickname(body.nickname),mode:body.mode,metaId:body.metaId,leagues:Array.isArray(body.leagues)?body.leagues:[]},now());}catch(e){return json({error:e.message},400);}
    const put=await bucket.put('rooms/v3/'+code,JSON.stringify(room),{onlyIf:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json'}});if(!put)return json({error:'Не удалось выделить код. Повторите создание.'},409);return json({room:core.snapshot(room,userId,now())},201);
   }
   const match=path.match(/^\/api\/rooms\/([^/]+)(?:\/(join|ready|move|rematch))?$/);if(!match||!codeOK(match[1]))return json({error:'Маршрут не найден'},404);
   const action=request.method==='GET'&&!match[2]?'read':request.method==='POST'?match[2]:null;if(!action)return json({error:'Метод недоступен'},405);
   return update(bucket,match[1],userId,action,body);
  }
  if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});
  const asset=assets[path==='/'?'/index.html':path];if(!asset)return new Response('Not found',{status:404});const bytes=Uint8Array.from(atob(asset.data),c=>c.charCodeAt(0));return new Response(request.method==='HEAD'?null:bytes,{headers:{'Content-Type':asset.type,'Cache-Control':/\.(webp|svg)$/.test(path)?'public, max-age=86400':'no-cache','X-Content-Type-Options':'nosniff'}});
 }
 return {async fetch(request,env){try{return await handle(request,env);}catch(e){console.error('Draftlab server error',e?.message);return json({error:'Не удалось синхронизировать комнату. Повторите запрос.'},503);}}};
}
const api={makeServer};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.DraftServer=api;
})(typeof globalThis!=='undefined'?globalThis:this);
